import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { RfpAnalysis, TechnicalAnalysis, TechnicalMatch, PriceEstimate } from '../types';
import { PRODUCT_INVENTORY } from '../inventory';

// Robustness: Retry utility for API calls
async function withRetry<T>(fn: () => Promise<T>, retries = 3, delay = 1000): Promise<T> {
  try {
    return await fn();
  } catch (e: any) {
    if (retries > 0) {
      console.warn(`API call failed. Retrying in ${delay}ms... (${retries} retries left)`);
      await new Promise(res => setTimeout(res, delay));
      return withRetry(fn, retries - 1, delay * 2); // Exponential backoff
    } else {
      console.error("API call failed after all retries.");
      throw e;
    }
  }
}

// Generic helper for JSON generation, now with retry logic
async function generateJson<T>(ai: GoogleGenAI, prompt: string, schema: any): Promise<T> {
  const apiCall = async () => {
      const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: schema,
        },
      });
      
      const jsonString = response.text.trim();
      try {
        return JSON.parse(jsonString) as T;
      } catch (e) {
        console.error("Failed to parse JSON:", jsonString);
        throw new Error("Received invalid JSON from API.");
      }
  };
  return withRetry(apiCall);
}

// Sales Agent: Finds an RFP and creates contextual summaries for other agents
export const runSalesAgentTask = async (ai: GoogleGenAI, urls: string): Promise<RfpAnalysis> => {
  const today = new Date();
  const todayFormatted = today.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  
  try {
    // --- ATTEMPT 1: REAL SEARCH ---
    console.log("Attempting to find a real RFP with Google Search...");
    const findRfpPrompt = `
      You are a Sales AI Agent for RFP_agent_Wire, a leading industrial manufacturer of wires and cables in India.
      Use Google Search to find a recent, real-world B2B Request for Proposal (RFP) for a large-scale project located in India requiring industrial cables.
      
      **CRITICAL REQUIREMENT:** The RFP's submission due date MUST be between 60 and 90 days from today's date, which is ${todayFormatted}.
      
      The user provided hint URLs: ${urls}. Perform a thorough search and select the single most relevant RFP that meets the date criteria.
      
      If you find a suitable RFP, extract its title, direct URL, and submission due date. Return a single, clean JSON object with no other text.
      Structure: {"title": "...", "url": "...", "dueDate": "..."}

      **FAILURE CONDITION:** If you absolutely cannot find an RFP that meets these exact criteria after your search, you MUST return the following JSON object and nothing else:
      {"error": "No suitable RFP found within the 60-90 day window."}
    `;

    const findResponse: GenerateContentResponse = await withRetry(() => ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: findRfpPrompt,
      config: { tools: [{googleSearch: {}}] },
    }));

    const responseText = findResponse.text;
    const jsonMatch = responseText.match(/{[\s\S]*}/);

    if (!jsonMatch) {
      throw new Error(`The AI did not return a valid JSON object. Response: "${responseText.slice(0, 100)}..."`);
    }
    
    const jsonString = jsonMatch[0];
    const rfpDetails = JSON.parse(jsonString);

    if (rfpDetails.error) {
      throw new Error(rfpDetails.error);
    }

    if (!rfpDetails.title || !rfpDetails.url || !rfpDetails.dueDate) {
      throw new Error("Required fields (title, url, dueDate) are missing from the AI response.");
    }

    const dueDate = new Date(rfpDetails.dueDate);
    const timeDiff = dueDate.getTime() - today.getTime();
    const daysDiff = timeDiff / (1000 * 3600 * 24);

    if (isNaN(daysDiff) || daysDiff < 60 || daysDiff > 90) {
      throw new Error(`The found RFP's due date (${rfpDetails.dueDate}) is outside the required 60-90 day window.`);
    }
    
    console.log("Successfully found a real RFP:", rfpDetails.title);
    
    // If real RFP is found, generate summaries in a second call (necessary because search tool doesn't support JSON mode)
    const summarizePrompt = `
      You are an Orchestrator Agent. Based on the identified RFP titled "${rfpDetails.title}", generate two distinct summaries:
      1.  **technicalSummary**: A summary for the Product Technical Team. Focus on the core product requirements, specifications, and scope of supply.
      2.  **pricingSummary**: A summary for the Pricing Team. Focus on testing requirements, acceptance criteria, and any other cost-related items.
      
      Return a single JSON object containing these two summaries.
    `;
    const summarySchema = {
      type: Type.OBJECT,
      properties: {
          technicalSummary: { type: Type.STRING },
          pricingSummary: { type: Type.STRING },
      },
      required: ['technicalSummary', 'pricingSummary'],
    };
    const summaries = await generateJson<{ technicalSummary: string; pricingSummary: string; }>(ai, summarizePrompt, summarySchema);

    return { details: rfpDetails, ...summaries };

  } catch (e: any) {
    // --- ATTEMPT 2: FALLBACK TO SIMULATION (COMBINED INTO ONE CALL) ---
    console.warn(`Real RFP search failed: "${e.message}". Falling back to simulation.`);
    
    const futureDate = new Date();
    futureDate.setDate(today.getDate() + 75);
    const futureDateFormatted = futureDate.toISOString().split('T')[0];

    const simulateAndSummarizePrompt = `
      You are a Sales AI Agent for RFP_agent_Wire, creating a realistic but fictional simulation.
      Your previous search for a real-world B2B Request for Proposal (RFP) failed.
      
      **Your Task:**
      1.  **Invent RFP Details:** Create a single, plausible RFP for a large-scale project in India.
          - **Title:** A professional, realistic title (e.g., "RFP for Cable Supply for the Mumbai Metro Line 3 Expansion").
          - **URL:** A realistic-looking but fictional URL (e.g., "https://tenders.mahametro.org.in/rfp-2024-cables").
          - **Due Date:** The due date MUST be exactly **${futureDateFormatted}**.
      2.  **Generate Summaries:** Based on your invented RFP, create two distinct summaries:
          - **technicalSummary**: For the Product Technical Team. Focus on fictional core product requirements, specs, and scope.
          - **pricingSummary**: For the Pricing Team. Focus on fictional testing requirements, acceptance criteria, and cost-related items.
      
      Return a single, clean JSON object conforming to the schema.
    `;
    
    const rfpAnalysisSchema = {
        type: Type.OBJECT,
        properties: {
            details: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING },
                    url: { type: Type.STRING },
                    dueDate: { type: Type.STRING },
                },
                required: ['title', 'url', 'dueDate'],
            },
            technicalSummary: { type: Type.STRING },
            pricingSummary: { type: Type.STRING },
        },
        required: ['details', 'technicalSummary', 'pricingSummary'],
    };

    const simulatedResult = await generateJson<RfpAnalysis>(ai, simulateAndSummarizePrompt, rfpAnalysisSchema);
    console.log("Generated a simulated RFP and summaries:", simulatedResult.details.title);
    return simulatedResult;
  }
};


// Combined Technical and Pricing Agent to reduce API calls
export const runCombinedTechAndPricingAgentTask = async (
    ai: GoogleGenAI, 
    technicalSummary: string, 
    pricingSummary: string
): Promise<{ technicalAnalysis: TechnicalAnalysis, priceEstimate: PriceEstimate }> => {
  const inventoryString = JSON.stringify(PRODUCT_INVENTORY, null, 2);
  const prompt = `
    You are a multi-skilled AI Agent for **RFP_agent_Wire**, a leading manufacturer of wires and cables in India, acting as both a Technical and Pricing specialist.
    You have received a technical summary of an RFP: "${technicalSummary}".
    The RFP's pricing-relevant requirements are: "${pricingSummary}".

    **Your Internal Product Inventory:**
    \`\`\`json
    ${inventoryString}
    \`\`\`

    **Your Combined Task:**

    **Part 1: Technical Matching**
    1.  Search **ONLY** within your provided internal product inventory to find the top 3 product SKUs that best match the RFP requirements.
    2.  For each of the top 3 matches, you must:
        -   Determine its 'rank' (1, 2, or 3).
        -   Use the exact 'oem_sku', 'voltage_rating', 'temperature_resistance', and 'environmental_certifications' from the inventory data.
        -   Calculate a "spec_match_percent" (between 85-100%) based on how well the product's description and specs align with the RFP summary. A 100% match is possible if it's a perfect fit.
        -   Use the product's 'description' field from the inventory as the value for 'source_details'.
        -   Set 'source_page' to an empty array: [].
    3.  Create a concise 'comparisonTableMarkdown' string for these 3 recommendations. The table must have headers: Rank, SKU, Spec Match, Voltage, Temp. Resistance, Certs, and Details.
    4.  From your top 3 recommendations, identify the single best option as the 'finalSelection'. This should be the complete object for that product from your recommendations.

    **Part 2: Cost Estimation (for your final selection)**
    1.  Based on your 'finalSelection' from Part 1 and the pricing summary, create a price estimate in Indian Rupees (INR).
    2.  The total cost should be between ₹4,000,000 and ₹20,000,000. Break it down into material and services/testing prices.
    3.  Provide a short 'pricing_details' sentence explaining the estimate.

    Return a single, clean JSON object with two top-level keys: 'technicalAnalysis' and 'priceEstimate', conforming to the schema.
  `;
  
  const recommendationSchema = {
    type: Type.OBJECT,
    properties: {
      rank: { type: Type.INTEGER },
      oem_sku: { type: Type.STRING },
      spec_match_percent: { type: Type.STRING },
      source_details: { type: Type.STRING },
      source_page: { type: Type.ARRAY, items: { type: Type.INTEGER } },
      voltage_rating: { type: Type.STRING },
      temperature_resistance: { type: Type.STRING },
      environmental_certifications: { type: Type.ARRAY, items: { type: Type.STRING } },
    },
    required: ['rank', 'oem_sku', 'spec_match_percent', 'source_details', 'source_page', 'voltage_rating', 'temperature_resistance', 'environmental_certifications'],
  };
  
  const technicalAnalysisSchema = {
      type: Type.OBJECT,
      properties: {
          recommendations: { type: Type.ARRAY, items: recommendationSchema },
          comparisonTableMarkdown: { type: Type.STRING },
          finalSelection: recommendationSchema
      },
      required: ['recommendations', 'comparisonTableMarkdown', 'finalSelection'],
  };
  
  const priceEstimateSchema = {
      type: Type.OBJECT,
      properties: {
          total_material_price: { type: Type.NUMBER },
          total_services_price: { type: Type.NUMBER },
          total_project_cost: { type: Type.NUMBER },
          pricing_details: { type: Type.STRING },
      },
      required: ['total_material_price', 'total_services_price', 'total_project_cost', 'pricing_details'],
  };

  const combinedSchema = {
    type: Type.OBJECT,
    properties: {
      technicalAnalysis: technicalAnalysisSchema,
      priceEstimate: priceEstimateSchema,
    },
    required: ['technicalAnalysis', 'priceEstimate'],
  };

  return generateJson<{ technicalAnalysis: TechnicalAnalysis, priceEstimate: PriceEstimate }>(ai, prompt, combinedSchema);
};

// Orchestrator Agent: Consolidates all info into a final report
export const generateFinalReport = async (ai: GoogleGenAI, rfpAnalysis: RfpAnalysis, techAnalysis: TechnicalAnalysis, estimate: PriceEstimate): Promise<string> => {
    const prompt = `
    You are the Main Orchestrator Agent for RFP_agent_Wire. Your task is to consolidate all findings into a professional, client-facing B2B RFP response draft using markdown.

    **CRITICAL INSTRUCTION:** This is a final draft for the customer. Do NOT include any internal metrics such as "Spec Match %". This information is for internal use only.

    **RFP Details:**
    - Title: ${rfpAnalysis.details.title}
    - URL: ${rfpAnalysis.details.url}
    - Due Date: ${rfpAnalysis.details.dueDate || 'Not specified'}

    **Technical Recommendation:**
    - Final Selected SKU: ${techAnalysis.finalSelection.oem_sku}
    
    **Comparison Table (Internal Data):**
    ${techAnalysis.comparisonTableMarkdown}

    **Pricing Estimate:**
    - Total Cost: ₹${estimate.total_project_cost.toLocaleString('en-IN')}
    - Details: ${estimate.pricing_details}

    **Your Action:**
    Based on all the information provided, generate a concise final summary. 
    1. Start with "### RFP Response Draft".
    2. Re-create the comparison table, but OMIT the "Spec Match" column entirely.
    3. Do not mention the "Spec Match" percentage anywhere in your response.
  `;
  const apiCall = () => ai.models.generateContent({model: 'gemini-2.5-pro', contents: prompt});
  // FIX: Explicitly type `response` as `GenerateContentResponse` to resolve the 'unknown' type from withRetry.
  const response: GenerateContentResponse = await withRetry(apiCall);
  return response.text;
};