
import React from 'react';
import { WorkflowStep, AgentName, WorkflowStepStatus } from './types';
import SearchIcon from './components/icons/SearchIcon';
import WrenchIcon from './components/icons/WrenchIcon';
import DollarIcon from './components/icons/DollarIcon';

export const WORKFLOW_STEPS: WorkflowStep[] = [
  {
    agentName: AgentName.SALES,
    title: 'Identification & Filtering',
    status: WorkflowStepStatus.PENDING,
    icon: React.createElement(SearchIcon),
  },
  {
    agentName: AgentName.TECHNICAL,
    title: 'Technical Matching',
    status: WorkflowStepStatus.PENDING,
    icon: React.createElement(WrenchIcon),
  },
  {
    agentName: AgentName.PRICING,
    title: 'Cost Estimation',
    status: WorkflowStepStatus.PENDING,
    icon: React.createElement(DollarIcon),
  },
];
