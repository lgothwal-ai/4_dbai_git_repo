
import React, { useReducer, useCallback, useEffect, useRef } from 'react';
import { GoogleGenAI } from '@google/genai';

import { AgentName, RfpAnalysis, TechnicalAnalysis, PriceEstimate, WorkflowStepStatus, WorkflowAction, WorkflowState } from './types';
import { WORKFLOW_STEPS } from './constants';
import * as geminiService from './services/geminiService';

import Header from './components/Header';
import WorkflowTracker from './components/WorkflowTracker';
import AgentCard from './components/AgentCard';
import FinalReport from './components/FinalReport';

// A simple utility to simulate network delay for better UX
const delay = (ms: number) => new Promise(res => setTimeout(res, ms));
const RUN_INTERVAL_MS = 6 * 60 * 60 * 1000; // 6 hours
const DEFAULT_RFP_URLS = 'http://sample-rfp-host.com/main, http://gov-tenders.com/new';

const initialState: WorkflowState = {
  steps: WORKFLOW_STEPS,
  currentStepIndex: 0,
  isLoading: false,
  error: null,
  rfpAnalysis: null,
  technicalAnalysis: null,
  priceEstimate: null,
  finalReport: '',
  lastRun: null,
  nextRun: null,
  countdown: '',
};

function workflowReducer(state: WorkflowState, action: WorkflowAction): WorkflowState {
  switch (action.type) {
    case 'START_WORKFLOW':
      return {
        ...initialState,
        isLoading: true,
        lastRun: new Date(),
        nextRun: new Date(new Date().getTime() + RUN_INTERVAL_MS),
      };
    case 'SET_STEP_STATUS':
      return {
        ...state,
        steps: state.steps.map((step, i) => 
          i === action.payload.index ? { ...step, status: action.payload.status } : step
        ),
        currentStepIndex: action.payload.index,
      };
    case 'SET_SALES_RESULTS':
      return { ...state, rfpAnalysis: action.payload };
    case 'SET_TECH_RESULTS':
      return { ...state, technicalAnalysis: action.payload };
    case 'SET_PRICE_RESULTS':
      return { ...state, priceEstimate: action.payload };
    case 'SET_FINAL_REPORT':
      return { ...state, finalReport: action.payload };
    case 'WORKFLOW_COMPLETE':
      return { ...state, isLoading: false, currentStepIndex: state.steps.length };
    case 'WORKFLOW_ERROR':
      const stepName = state.steps[state.currentStepIndex]?.agentName || 'an unknown step';
      return {
        ...state,
        isLoading: false,
        error: `An error occurred at the ${stepName} step: ${action.payload.message}`,
        steps: state.steps.map((step, i) =>
          i === state.currentStepIndex ? { ...step, status: WorkflowStepStatus.PENDING } : step
        ),
      };
    case 'UPDATE_TIMER':
      return { ...state, countdown: action.payload };
    default:
      return state;
  }
}

interface AutomationStatusProps {
  isLoading: boolean;
  lastRun: Date | null;
  countdown: string;
  onManualRun: () => void;
}

const AutomationStatus: React.FC<AutomationStatusProps> = ({ isLoading, lastRun, countdown, onManualRun }) => {
  return (
    <div className="w-full max-w-4xl mx-auto mb-8 p-4 bg-gray-800/70 backdrop-blur-sm border border-gray-700 rounded-xl shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
      <div className="text-center sm:text-left">
        <h2 className="text-lg font-bold text-white">Live Automation Status</h2>
        <div className="text-sm text-gray-400 sm:space-x-4">
          <span>
            {lastRun ? `Last scan: ${lastRun.toLocaleTimeString()}` : 'Initializing first scan...'}
          </span>
          <span className="hidden sm:inline">|</span>
          <span className="block sm:inline mt-1 sm:mt-0">
            Next scan in: <strong className="font-mono text-cyan-400">{countdown || '...'}</strong>
          </span>
        </div>
      </div>
      <button
        onClick={onManualRun}
        disabled={isLoading}
        className="bg-cyan-600 w-full sm:w-auto hover:bg-cyan-700 disabled:bg-gray-600 disabled:cursor-wait text-white font-bold py-2 px-6 rounded-lg transition duration-300 ease-in-out shrink-0"
      >
        {isLoading ? 'Scanning...' : 'Scan Now'}
      </button>
    </div>
  );
};


const App: React.FC = () => {
  const [state, dispatch] = useReducer(workflowReducer, initialState);
  const { 
      steps, currentStepIndex, isLoading, error, 
      rfpAnalysis, technicalAnalysis, priceEstimate, finalReport,
      lastRun, nextRun, countdown
  } = state;

  const startWorkflow = useCallback(async (urls: string) => {
    dispatch({ type: 'START_WORKFLOW' });
    
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
    
    try {
      // Step 0: Sales Agent
      dispatch({ type: 'SET_STEP_STATUS', payload: { index: 0, status: WorkflowStepStatus.IN_PROGRESS }});
      const salesResult = await geminiService.runSalesAgentTask(ai, urls);
      dispatch({ type: 'SET_SALES_RESULTS', payload: salesResult });
      dispatch({ type: 'SET_STEP_STATUS', payload: { index: 0, status: WorkflowStepStatus.COMPLETED }});
      await delay(1000);

      // Step 1 & 2: Combined Technical & Pricing Agent
      dispatch({ type: 'SET_STEP_STATUS', payload: { index: 1, status: WorkflowStepStatus.IN_PROGRESS }});
      dispatch({ type: 'SET_STEP_STATUS', payload: { index: 2, status: WorkflowStepStatus.IN_PROGRESS }});
      const { technicalAnalysis: techResult, priceEstimate: priceResult } = await geminiService.runCombinedTechAndPricingAgentTask(ai, salesResult.technicalSummary, salesResult.pricingSummary);
      dispatch({ type: 'SET_TECH_RESULTS', payload: techResult });
      dispatch({ type: 'SET_PRICE_RESULTS', payload: priceResult });
      dispatch({ type: 'SET_STEP_STATUS', payload: { index: 1, status: WorkflowStepStatus.COMPLETED }});
      dispatch({ type: 'SET_STEP_STATUS', payload: { index: 2, status: WorkflowStepStatus.COMPLETED }});
      await delay(1000);

      // Step 3: Main Agent (Orchestrator) for Final Report
      dispatch({ type: 'SET_STEP_STATUS', payload: { index: 3, status: WorkflowStepStatus.IN_PROGRESS }});
      const report = await geminiService.generateFinalReport(ai, salesResult, techResult, priceResult);
      dispatch({ type: 'SET_FINAL_REPORT', payload: report });
      dispatch({ type: 'SET_STEP_STATUS', payload: { index: 3, status: WorkflowStepStatus.COMPLETED }});
      dispatch({ type: 'WORKFLOW_COMPLETE' });

    } catch (e: any) {
      console.error(e);
      dispatch({ type: 'WORKFLOW_ERROR', payload: e });
    }
  }, []);

  const workflowRef = useRef(startWorkflow);
  useEffect(() => { workflowRef.current = startWorkflow; }, [startWorkflow]);

  const isLoadingRef = useRef(isLoading);
  useEffect(() => { isLoadingRef.current = isLoading; }, [isLoading]);
  
  // Effect for scheduling automatic runs
  useEffect(() => {
    const runAndSchedule = () => {
        if (isLoadingRef.current) {
          console.log("Skipping scheduled run: a workflow is already in progress.");
          return;
        }
        workflowRef.current(DEFAULT_RFP_URLS);
    };
    
    runAndSchedule(); // Initial run on load
    const intervalId = setInterval(runAndSchedule, RUN_INTERVAL_MS);
    
    return () => clearInterval(intervalId);
  }, []); // Run only once on component mount

  // Effect for the countdown timer
  useEffect(() => {
    if (!nextRun) return;
    
    const timer = setInterval(() => {
        const now = new Date().getTime();
        const distance = nextRun.getTime() - now;

        if (distance < 0) {
            dispatch({ type: 'UPDATE_TIMER', payload: 'Starting new scan...' });
            return;
        }

        const hours = Math.floor(distance / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        const countdownStr = `${String(hours).padStart(2, '0')}h ${String(minutes).padStart(2, '0')}m ${String(seconds).padStart(2, '0')}s`;
        dispatch({ type: 'UPDATE_TIMER', payload: countdownStr });
    }, 1000);

    return () => clearInterval(timer);
  }, [nextRun]);

  const handleManualRun = useCallback(() => {
    if (!isLoadingRef.current) {
      // FIX: Corrected a typo in the constant name.
      workflowRef.current(DEFAULT_RFP_URLS);
    }
  }, []);
  
  const getAgentResults = (agentName: AgentName) => {
    switch (agentName) {
      case AgentName.SALES: return rfpAnalysis;
      case AgentName.TECHNICAL: return technicalAnalysis;
      case AgentName.PRICING: return priceEstimate;
      default: return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white font-sans">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <AutomationStatus 
            isLoading={isLoading}
            lastRun={lastRun}
            countdown={countdown}
            onManualRun={handleManualRun}
        />
        <WorkflowTracker steps={steps} currentStepIndex={currentStepIndex} />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
            {steps.map((step) => (
            <AgentCard
                key={step.agentName}
                icon={step.icon}
                title={step.title}
                status={step.status}
                results={getAgentResults(step.agentName)}
            />
            ))}
        </div>
        {finalReport && <FinalReport report={finalReport} />}
        {error && <div className="mt-8 p-4 bg-red-900/50 border border-red-700 rounded-lg text-red-300 text-center">{error}</div>}
      </main>
    </div>
  );
};

export default App;