
import React from 'react';
import { WorkflowStep, WorkflowStepStatus } from '../types';
import CheckIcon from './icons/CheckIcon';
import CogIcon from './icons/CogIcon';

interface WorkflowTrackerProps {
  steps: WorkflowStep[];
  currentStepIndex: number;
}

const WorkflowTracker: React.FC<WorkflowTrackerProps> = ({ steps, currentStepIndex }) => {
  const getStepStatus = (index: number): WorkflowStepStatus => {
    if (steps[index].status === WorkflowStepStatus.COMPLETED) return WorkflowStepStatus.COMPLETED;
    if (index === currentStepIndex) return WorkflowStepStatus.IN_PROGRESS;
    return WorkflowStepStatus.PENDING;
  }

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="flex items-center justify-between">
        {steps.map((step, index) => {
          const status = getStepStatus(index);
          const isCompleted = status === WorkflowStepStatus.COMPLETED;
          const isInProgress = status === WorkflowStepStatus.IN_PROGRESS;

          return (
            <React.Fragment key={step.agentName}>
              <div className="flex flex-col items-center text-center w-1/3">
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center border-2 transition-all duration-500 ${
                    isCompleted ? 'bg-green-500 border-green-400' : 
                    isInProgress ? 'bg-cyan-500 border-cyan-400 animate-pulse' : 
                    'bg-gray-700 border-gray-600'
                  }`}
                >
                  {isCompleted ? <CheckIcon /> : isInProgress ? <CogIcon className="animate-spin" /> : step.icon}
                </div>
                <p className={`mt-2 font-semibold text-sm transition-colors duration-500 ${
                  isCompleted || isInProgress ? 'text-white' : 'text-gray-500'
                }`}>
                  {step.agentName}
                </p>
                <p className={`text-xs ${
                  isCompleted || isInProgress ? 'text-gray-300' : 'text-gray-600'
                }`}>
                  {step.title}
                </p>
              </div>
              {index < steps.length - 1 && (
                <div className="flex-1 h-1 bg-gray-700 rounded-full relative">
                    <div 
                        className="absolute top-0 left-0 h-1 bg-cyan-500 rounded-full transition-all duration-1000 ease-out"
                        style={{ width: index < currentStepIndex ? '100%' : (index === currentStepIndex && isInProgress ? '50%' : '0%') }}
                    ></div>
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
};

export default WorkflowTracker;
