import React from 'react';
import { WorkflowStepStatus, RfpAnalysis, TechnicalAnalysis, PriceEstimate } from '../types';
import CheckIcon from './icons/CheckIcon';
import CogIcon from './icons/CogIcon';

const renderResults = (results: RfpAnalysis | TechnicalAnalysis | PriceEstimate | null) => {
  if (!results) return null;

  // RfpAnalysis from Sales Agent
  if ('details' in results && 'technicalSummary' in results) {
    const rfp = results.details;
    return (
      <div className="text-sm space-y-2 flex flex-col h-full">
        <div>
            <p className="font-semibold text-gray-300 mb-1">RFP Identified:</p>
            <p className="text-cyan-400 break-words font-medium">{rfp.title}</p>
        </div>
        <div className="flex-grow pt-2 space-y-3 overflow-y-auto pr-2" style={{ maxHeight: '150px' }}>
           <p className="text-xs text-gray-400 font-semibold">Key Requirements Summary:</p>
           <div className="pl-2 border-l-2 border-gray-700/50">
               <p className="font-medium text-gray-500 text-xs">Technical</p>
               <p className="text-xs text-gray-300 italic">"{results.technicalSummary}"</p>
           </div>
           <div className="pl-2 border-l-2 border-gray-700/50">
               <p className="font-medium text-gray-500 text-xs">Pricing & Terms</p>
               <p className="text-xs text-gray-300 italic">"{results.pricingSummary}"</p>
           </div>
        </div>
        <div className="mt-auto pt-2 border-t border-gray-700/50 space-y-2">
            {rfp.dueDate && (
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-gray-400">Due Date:</span>
                <span className="font-mono text-amber-400 bg-gray-900/50 px-2 py-1 rounded">{rfp.dueDate}</span>
              </div>
            )}
             <a href={rfp.url} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300 hover:underline break-all text-xs block truncate">
              Source: {rfp.url}
            </a>
        </div>
      </div>
    );
  }

  // TechnicalAnalysis from Technical Agent
  if ('recommendations' in results && 'finalSelection' in results) {
    return (
      <div className="text-sm space-y-3">
        <p className="font-semibold text-gray-300">Top SKU Recommendations:</p>
        <div className="space-y-2">
          {results.recommendations.map(match => (
            <div key={match.rank} className={`p-2 rounded-md transition-all ${match.oem_sku === results.finalSelection.oem_sku ? 'bg-cyan-900/70 ring-1 ring-cyan-500' : 'bg-gray-900/50'}`}>
              <div className="flex justify-between items-center font-bold">
                <span className="text-cyan-400">{match.oem_sku}</span>
                <span className="text-green-400">{match.spec_match_percent}</span>
              </div>
              <div className="text-xs text-gray-400 mt-2 space-y-1 border-t border-gray-700/50 pt-2">
                  <div className="flex justify-between">
                    <span className="font-semibold text-gray-300">Voltage:</span>
                    <span>{match.voltage_rating}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-semibold text-gray-300">Temp:</span>
                    <span>{match.temperature_resistance}</span>
                  </div>
                  {match.environmental_certifications && match.environmental_certifications.length > 0 && 
                    <div className="flex justify-between">
                      <span className="font-semibold text-gray-300">Certs:</span>
                      <span className="text-right">{match.environmental_certifications.join(', ')}</span>
                    </div>
                  }
               </div>
               {match.oem_sku === results.finalSelection.oem_sku && <p className="text-xs text-cyan-300 font-bold mt-2 pt-2 border-t border-cyan-800/50">✔︎ Final Selection</p>}
            </div>
          ))}
        </div>
      </div>
    );
  }

  // PriceEstimate from Pricing Agent
  if ('total_project_cost' in results) {
    return (
      <div className="text-sm space-y-2">
        <p className="font-semibold text-gray-300">Cost Breakdown:</p>
        <div className="flex justify-between"><span>Materials:</span> <span>₹{results.total_material_price.toLocaleString('en-IN')}</span></div>
        <div className="flex justify-between"><span>Services/Testing:</span> <span>₹{results.total_services_price.toLocaleString('en-IN')}</span></div>
        <hr className="border-gray-600" />
        <div className="flex justify-between font-bold text-lg text-green-400"><span>Total Est. Cost:</span> <span>₹{results.total_project_cost.toLocaleString('en-IN')}</span></div>
        <p className="text-xs text-gray-400 pt-2">{results.pricing_details}</p>
      </div>
    );
  }

  return null;
};

// FIX: Define AgentCardProps to provide types for the component's props.
interface AgentCardProps {
  icon: React.ReactNode;
  title: string;
  status: WorkflowStepStatus;
  results: RfpAnalysis | TechnicalAnalysis | PriceEstimate | null;
}

const AgentCard: React.FC<AgentCardProps> = ({ icon, title, status, results }) => {
  return (
    <div className="bg-gray-800/70 backdrop-blur-sm border border-gray-700 rounded-xl p-6 shadow-lg h-full flex flex-col transition-all duration-500">
      <div className="flex items-center mb-4">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center mr-4 ${
            status === WorkflowStepStatus.COMPLETED ? 'bg-green-500/20 text-green-400' :
            status === WorkflowStepStatus.IN_PROGRESS ? 'bg-cyan-500/20 text-cyan-400' :
            'bg-gray-700 text-gray-400'
        }`}>
          {
            status === WorkflowStepStatus.COMPLETED ? <CheckIcon /> :
            status === WorkflowStepStatus.IN_PROGRESS ? <CogIcon className="animate-spin"/> :
            icon
          }
        </div>
        <div>
            <h3 className="font-bold text-lg text-white">{title}</h3>
            <p className={`text-sm font-medium ${
                status === WorkflowStepStatus.COMPLETED ? 'text-green-400' :
                status === WorkflowStepStatus.IN_PROGRESS ? 'text-cyan-400 animate-pulse' :
                'text-gray-500'
            }`}>
              {status === WorkflowStepStatus.PENDING && 'Pending...'}
              {status === WorkflowStepStatus.IN_PROGRESS && 'Working...'}
              {status === WorkflowStepStatus.COMPLETED && 'Completed'}
            </p>
        </div>
      </div>
      <div className="flex-grow min-h-[100px] bg-gray-900/50 p-4 rounded-lg border border-gray-700/50 flex items-center justify-center">
        {status === WorkflowStepStatus.COMPLETED ? (
            <div className="w-full h-full">{renderResults(results)}</div>
        ) : status === WorkflowStepStatus.IN_PROGRESS ? (
            <p className="text-gray-400">Analyzing data...</p>
        ) : (
            <p className="text-gray-600">Awaiting previous step</p>
        )}
      </div>
    </div>
  );
};

export default AgentCard;