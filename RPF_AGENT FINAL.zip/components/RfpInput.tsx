
import React, { useState } from 'react';

interface RfpInputProps {
  onStart: (urls: string) => void;
  isLoading: boolean;
}

const RfpInput: React.FC<RfpInputProps> = ({ onStart, isLoading }) => {
  const [urls, setUrls] = useState<string>('http://sample-rfp-host.com/main, http://gov-tenders.com/new');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (urls.trim() && !isLoading) {
      onStart(urls);
    }
  };

  return (
    <div className="max-w-2xl mx-auto mt-16 text-center">
      <h2 className="text-4xl font-extrabold text-white mb-4">
        Automate Your B2B RFP Workflow
      </h2>
      <p className="text-lg text-gray-400 mb-8">
        Enter the URLs of tender portals. The AI agents will scan for relevant RFPs, analyze technical requirements, estimate costs, and generate a response draft.
      </p>
      <form onSubmit={handleSubmit} className="bg-gray-800 p-8 rounded-xl shadow-2xl border border-gray-700">
        <div className="flex flex-col">
          <label htmlFor="urls" className="text-left text-gray-300 font-medium mb-2">
            Target URLs (comma-separated)
          </label>
          <textarea
            id="urls"
            value={urls}
            onChange={(e) => setUrls(e.target.value)}
            placeholder="e.g., http://tenders.example.com, http://bids.example.gov"
            rows={3}
            className="w-full bg-gray-700 text-white rounded-md p-3 border border-gray-600 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition duration-200"
          />
        </div>
        <button
          type="submit"
          disabled={isLoading}
          className="mt-6 w-full bg-cyan-600 hover:bg-cyan-700 disabled:bg-gray-500 disabled:cursor-not-allowed text-white font-bold py-3 px-6 rounded-lg text-lg transition duration-300 ease-in-out transform hover:scale-105"
        >
          {isLoading ? 'Agents are Working...' : 'Start Analysis'}
        </button>
      </form>
    </div>
  );
};

export default RfpInput;
