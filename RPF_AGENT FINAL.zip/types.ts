// FIX: Import React to resolve the type 'React.ReactNode'.
import React from 'react';

export enum AgentName {
  SALES = 'Sales Agent',
  TECHNICAL = 'Technical Agent',
  PRICING = 'Pricing Agent',
  ORCHESTRATOR = 'Main Agent (Orchestrator)',
}

export enum WorkflowStepStatus {
  PENDING = 'pending',
  IN_PROGRESS = 'in_progress',
  COMPLETED = 'completed',
}

export interface WorkflowStep {
  agentName: AgentName;
  title: string;
  status: WorkflowStepStatus;
  icon: React.ReactNode;
}

// Represents the output of the Sales Agent
export interface RfpAnalysis {
  details: {
    title: string;
    url: string;
    dueDate?: string;
  };
  technicalSummary: string;
  pricingSummary: string;
}

export interface TechnicalMatch {
  rank: number;
  oem_sku: string;
  spec_match_percent: string;
  source_details: string;
  source_page: number[];
  voltage_rating: string;
  temperature_resistance: string;
  environmental_certifications: string[];
}

// Represents the output of the Technical Agent
export interface TechnicalAnalysis {
  recommendations: TechnicalMatch[];
  comparisonTableMarkdown: string;
  finalSelection: TechnicalMatch;
}

export interface PriceEstimate {
  total_material_price: number;
  total_services_price: number;
  total_project_cost: number;
  pricing_details: string;
}

// Types for useReducer state and actions
export interface WorkflowState {
  steps: WorkflowStep[];
  currentStepIndex: number;
  isLoading: boolean;
  error: string | null;
  rfpAnalysis: RfpAnalysis | null;
  technicalAnalysis: TechnicalAnalysis | null;
  priceEstimate: PriceEstimate | null;
  finalReport: string;
  lastRun: Date | null;
  nextRun: Date | null;
  countdown: string;
}

export type WorkflowAction =
  | { type: 'START_WORKFLOW' }
  | { type: 'SET_STEP_STATUS'; payload: { index: number; status: WorkflowStepStatus } }
  | { type: 'SET_SALES_RESULTS'; payload: RfpAnalysis }
  | { type: 'SET_TECH_RESULTS'; payload: TechnicalAnalysis }
  | { type: 'SET_PRICE_RESULTS'; payload: PriceEstimate }
  | { type: 'SET_FINAL_REPORT'; payload: string }
  | { type: 'WORKFLOW_COMPLETE' }
  | { type: 'WORKFLOW_ERROR'; payload: Error }
  | { type: 'UPDATE_TIMER'; payload: string };