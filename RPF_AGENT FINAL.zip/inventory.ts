export interface InventoryProduct {
  oem_sku: string;
  description: string;
  voltage_rating: string;
  temperature_resistance: string;
  environmental_certifications: string[];
  tags: string[];
}

export const PRODUCT_INVENTORY: InventoryProduct[] = [
  {
    oem_sku: 'RFPW-LV-PWR-001A',
    description: 'Low-Voltage PVC Insulated Power Cable, 1.1kV, suitable for general industrial use and indoor wiring.',
    voltage_rating: '1.1kV',
    temperature_resistance: '0°C to 70°C',
    environmental_certifications: ['BIS IS 694', 'RoHS'],
    tags: ['low-voltage', 'power', 'pvc', 'industrial']
  },
  {
    oem_sku: 'RFPW-LV-CTL-002B',
    description: 'Multicore Low-Voltage Control Cable, XLPE insulated, for signaling and control circuits.',
    voltage_rating: '1.1kV',
    temperature_resistance: '-15°C to 90°C',
    environmental_certifications: ['BIS IS 1554', 'RoHS'],
    tags: ['low-voltage', 'control', 'xlpe', 'multicore']
  },
  {
    oem_sku: 'RFPW-MV-PWR-003C',
    description: 'Medium-Voltage Armoured Power Cable, XLPE insulated, for underground distribution networks.',
    voltage_rating: '11kV',
    temperature_resistance: '-15°C to 90°C',
    environmental_certifications: ['BIS IS 7098', 'IEC 60502'],
    tags: ['medium-voltage', 'power', 'armoured', 'underground']
  },
  {
    oem_sku: 'RFPW-HV-PWR-004D',
    description: 'High-Voltage Armoured Power Cable for primary distribution and industrial feeders.',
    voltage_rating: '33kV',
    temperature_resistance: '-20°C to 90°C',
    environmental_certifications: ['BIS IS 7098 Part 2', 'IEC 60840', 'RoHS'],
    tags: ['high-voltage', 'power', 'armoured', 'distribution']
  },
  {
    oem_sku: 'RFPW-FR-BLD-005E',
    description: 'Flame Retardant (FR) Building Wire, single core, for residential and commercial building conduits.',
    voltage_rating: '1.1kV',
    temperature_resistance: '0°C to 70°C',
    environmental_certifications: ['BIS IS 694', 'CPRI Certified'],
    tags: ['flame-retardant', 'building', 'low-voltage', 'conduit']
  },
  {
    oem_sku: 'RFPW-FRLS-BLD-006F',
    description: 'Flame Retardant Low Smoke (FRLS) Cable for public areas like schools, hospitals, and metros.',
    voltage_rating: '1.1kV',
    temperature_resistance: '-5°C to 90°C',
    environmental_certifications: ['BIS IS 1554', 'RoHS', 'Fire Survival Test (IEC 60331)'],
    tags: ['flame-retardant', 'low-smoke', 'frls', 'public-safety']
  },
  {
    oem_sku: 'RFPW-SOL-DC-007G',
    description: 'DC Solar Cable, TUV certified, for connecting photovoltaic panels. UV and ozone resistant.',
    voltage_rating: '1.5kV DC',
    temperature_resistance: '-40°C to 120°C',
    environmental_certifications: ['TUV 2 PfG 1169/08.2007', 'RoHS', 'UV Resistant (HD 605/A1)'],
    tags: ['solar', 'dc', 'photovoltaic', 'outdoor']
  }
];
